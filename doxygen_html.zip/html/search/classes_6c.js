var searchData=
[
  ['logmessage',['LogMessage',['../class_log_message.html',1,'']]],
  ['logsystem',['LogSystem',['../class_log_system.html',1,'']]]
];
